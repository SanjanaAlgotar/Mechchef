import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const orderSchema = z.object({
  customerId: z.string().min(1),
  deliveryAddress: z.string().min(5),
  deliverySlot: z.string().min(3),
  items: z
    .array(
      z.object({
        mealId: z.string().min(1),
        quantity: z.number().int().positive(),
        unitPrice: z.number().positive()
      })
    )
    .min(1)
});

export async function GET() {
  const orders = await prisma.order.findMany({
    include: {
      customer: { select: { name: true, email: true } },
      items: { include: { meal: true } }
    },
    orderBy: { createdAt: "desc" }
  });

  return NextResponse.json({ orders });
}

export async function POST(request: Request) {
  const parsed = orderSchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid order payload" }, { status: 400 });
  }

  const subtotal = parsed.data.items.reduce(
    (sum, item) => sum + item.unitPrice * item.quantity,
    0
  );
  const deliveryFee = 1.99;
  const serviceFee = Number((subtotal * 0.08).toFixed(2));

  const order = await prisma.order.create({
    data: {
      customerId: parsed.data.customerId,
      deliveryAddress: parsed.data.deliveryAddress,
      deliverySlot: parsed.data.deliverySlot,
      subtotal,
      deliveryFee,
      serviceFee,
      total: Number((subtotal + deliveryFee + serviceFee).toFixed(2)),
      items: {
        create: parsed.data.items.map((item) => ({
          mealId: item.mealId,
          quantity: item.quantity,
          unitPrice: item.unitPrice
        }))
      }
    },
    include: {
      items: true
    }
  });

  return NextResponse.json({ order }, { status: 201 });
}
