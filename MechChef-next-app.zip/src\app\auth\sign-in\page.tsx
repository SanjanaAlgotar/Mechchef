import { ChefHat } from "lucide-react";
import Link from "next/link";

export default function SignInPage() {
  return (
    <main className="grid min-h-screen place-items-center bg-mech-cream px-4 py-10">
      <section className="w-full max-w-md rounded-xl border border-mech-line bg-white p-8 shadow-soft">
        <Link href="/" className="mb-8 flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-lg bg-mech-dark text-mech-gold">
            <ChefHat size={21} />
          </span>
          <span className="font-heading text-2xl font-black">
            Mech<span className="text-mech-red">Chef</span>
          </span>
        </Link>
        <p className="text-xs font-black uppercase tracking-widest text-mech-red">Account access</p>
        <h1 className="mt-2 font-heading text-4xl font-black">Sign in</h1>
        <form className="mt-7 grid gap-4">
          <label className="grid gap-2 text-sm font-bold">
            Email
            <input className="rounded-lg border border-mech-line px-4 py-3 font-semibold outline-none focus:border-mech-red" type="email" placeholder="you@example.com" />
          </label>
          <label className="grid gap-2 text-sm font-bold">
            Password
            <input className="rounded-lg border border-mech-line px-4 py-3 font-semibold outline-none focus:border-mech-red" type="password" placeholder="Minimum 6 characters" />
          </label>
          <button className="mt-2 rounded-lg bg-mech-red px-5 py-3 text-sm font-black text-white hover:bg-mech-dark" type="button">
            Continue
          </button>
        </form>
        <p className="mt-5 text-sm leading-6 text-mech-muted">
          NextAuth credentials are wired in `src/lib/auth.ts`; connect this form with `signIn("credentials")` when you add client-side submission.
        </p>
      </section>
    </main>
  );
}
