import { CreditCard, MapPin, Ticket } from "lucide-react";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { meals } from "@/lib/demo-data";

export default function CheckoutPage() {
  const selected = meals.slice(0, 2);
  const subtotal = selected.reduce((sum, meal) => sum + meal.price, 0);
  const delivery = 1.99;
  const total = subtotal + delivery;

  return (
    <main>
      <Header />
      <section className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <h1 className="mb-8 font-heading text-5xl font-black">Checkout</h1>
          <div className="grid gap-6 lg:grid-cols-[1.25fr_0.75fr]">
            <div className="grid gap-5">
              <div className="rounded-lg border border-mech-line bg-white p-6">
                <h2 className="mb-5 flex items-center gap-2 font-heading text-2xl font-bold">
                  <MapPin size={22} className="text-mech-red" />
                  Delivery address
                </h2>
                <div className="grid gap-3 sm:grid-cols-2">
                  <input className="rounded-lg border border-mech-line px-4 py-3 text-sm font-semibold outline-none sm:col-span-2" placeholder="Address line" />
                  <input className="rounded-lg border border-mech-line px-4 py-3 text-sm font-semibold outline-none" placeholder="Postcode" />
                  <select className="rounded-lg border border-mech-line px-4 py-3 text-sm font-semibold outline-none">
                    <option>12:00 - 13:00</option>
                    <option>13:00 - 14:00</option>
                    <option>18:00 - 19:00</option>
                    <option>19:00 - 20:00</option>
                  </select>
                </div>
              </div>

              <div className="rounded-lg border border-mech-line bg-white p-6">
                <h2 className="mb-5 flex items-center gap-2 font-heading text-2xl font-bold">
                  <Ticket size={22} className="text-mech-red" />
                  Coupons
                </h2>
                <div className="flex gap-2">
                  <input className="min-w-0 flex-1 rounded-lg border border-mech-line px-4 py-3 text-sm font-semibold outline-none" placeholder="Try MECH20" />
                  <button className="rounded-lg bg-mech-dark px-5 py-3 text-sm font-black text-white">Apply</button>
                </div>
              </div>
            </div>

            <aside className="rounded-lg border border-mech-line bg-white p-6">
              <h2 className="mb-5 font-heading text-2xl font-bold">Order summary</h2>
              <div className="grid gap-4">
                {selected.map((meal) => (
                  <div key={meal.id} className="flex justify-between gap-3 border-b border-mech-line pb-4 text-sm">
                    <div>
                      <strong>{meal.name}</strong>
                      <p className="text-mech-muted">{meal.cook}</p>
                    </div>
                    <span className="font-black">£{meal.price.toFixed(2)}</span>
                  </div>
                ))}
              </div>
              <div className="mt-5 grid gap-2 text-sm text-mech-muted">
                <div className="flex justify-between"><span>Subtotal</span><span>£{subtotal.toFixed(2)}</span></div>
                <div className="flex justify-between"><span>Delivery</span><span>£{delivery.toFixed(2)}</span></div>
                <div className="flex justify-between border-t border-mech-line pt-3 font-heading text-2xl font-black text-mech-dark">
                  <span>Total</span><span>£{total.toFixed(2)}</span>
                </div>
              </div>
              <button className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-mech-red px-5 py-4 text-sm font-black text-white hover:bg-mech-dark">
                <CreditCard size={18} />
                Pay securely with Stripe
              </button>
              <p className="mt-3 text-center text-xs font-semibold text-mech-muted">Secure checkout. GBP payments. UK delivery only.</p>
            </aside>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
