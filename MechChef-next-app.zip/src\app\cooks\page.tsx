import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { CookCard } from "@/components/CookCard";
import { cooks } from "@/lib/demo-data";

export default function CooksPage() {
  return (
    <main>
      <Header />
      <section className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-8 max-w-2xl">
            <p className="text-xs font-black uppercase tracking-widest text-mech-red">Verified network</p>
            <h1 className="font-heading text-5xl font-black">Home cooks</h1>
            <p className="mt-3 leading-7 text-mech-muted">
              Profiles include story, weekly menu, ratings, delivery timing, followers, hygiene verification, and performance signals.
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {cooks.map((cook) => (
              <CookCard key={cook.id} cook={cook} />
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
