import { CheckCircle2, ChefHat, PackageCheck, Star, Truck } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";

const steps: { label: string; icon: LucideIcon }[] = [
  { label: "Order confirmed", icon: CheckCircle2 },
  { label: "Preparing by cook", icon: ChefHat },
  { label: "Picked up", icon: PackageCheck },
  { label: "Out for delivery", icon: Truck },
  { label: "Delivered and reviewed", icon: Star }
];

export default function OrdersPage() {
  return (
    <main>
      <Header />
      <section className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl">
          <p className="text-xs font-black uppercase tracking-widest text-mech-red">Live tracking</p>
          <h1 className="font-heading text-5xl font-black">Track your order</h1>
          <div className="mt-8 rounded-xl border border-mech-line bg-white p-6 shadow-sm">
            <div className="mb-6 rounded-lg bg-mech-dark p-5 text-white">
              <p className="text-sm font-semibold text-white/60">Order MCH-1024</p>
              <h2 className="mt-1 font-heading text-3xl font-black">Preparing by cook</h2>
              <p className="mt-2 text-sm text-white/70">Estimated delivery: 18:35 - 18:50</p>
            </div>
            <div className="grid gap-4">
              {steps.map(({ label, icon: Icon }, index) => (
                <div key={label} className="flex items-center gap-4">
                  <span className={`grid h-11 w-11 place-items-center rounded-full ${index < 2 ? "bg-mech-red text-white" : "bg-mech-cream text-mech-muted"}`}>
                    <Icon size={20} />
                  </span>
                  <div className="flex-1 border-b border-mech-line pb-4">
                    <strong>{label}</strong>
                    <p className="text-sm text-mech-muted">{index < 2 ? "Completed" : "Waiting"}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  );
}
