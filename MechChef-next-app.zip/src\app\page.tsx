import Link from "next/link";
import { ArrowRight, BadgeCheck, Clock, MapPin, Search, ShieldCheck, Star, Utensils } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { CookCard } from "@/components/CookCard";
import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { MealCard } from "@/components/MealCard";
import { cooks, cuisines, meals } from "@/lib/demo-data";

const platformFeatures: { icon: LucideIcon; title: string; text: string }[] = [
  {
    icon: Utensils,
    title: "Browse and filter",
    text: "Search by cuisine, postcode, dietary need, cook, price, and delivery time."
  },
  {
    icon: BadgeCheck,
    title: "Verified kitchens",
    text: "Cook onboarding, compliance checks, reviews, and quality control."
  },
  {
    icon: Clock,
    title: "Track every order",
    text: "Confirmed, preparing, picked up, out for delivery, delivered, then review."
  },
  {
    icon: Star,
    title: "Grow the community",
    text: "Loyalty, subscriptions, favourites, and corporate bulk orders."
  }
];

export default function HomePage() {
  return (
    <main>
      <Header />
      <section className="hero-texture relative min-h-[680px] overflow-hidden">
        <div className="mx-auto grid min-h-[680px] max-w-7xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:px-8">
          <div className="max-w-3xl text-white">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm font-bold text-white/85 backdrop-blur">
              <ShieldCheck size={17} />
              Verified home cooks launching in Harrow and Newham
            </div>
            <h1 className="font-heading text-5xl font-black leading-[1.02] sm:text-7xl">
              Home cooked meals from real kitchens across London
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-white/75">
              Search by dish, cuisine, cook, or postcode. Pre-order fresh tiffins and family plates from trusted local cooks, with payments, tracking, and reviews built in.
            </p>
            <div className="mt-8 rounded-xl border border-white/20 bg-white p-2 shadow-soft">
              <div className="grid gap-2 md:grid-cols-[1fr_170px_auto]">
                <label className="flex items-center gap-3 rounded-lg bg-mech-cream px-4 py-3 text-mech-muted">
                  <Search size={18} />
                  <input className="w-full bg-transparent text-sm font-semibold outline-none placeholder:text-mech-muted" placeholder="Search biryani, daal, jerk chicken..." />
                </label>
                <label className="flex items-center gap-3 rounded-lg bg-mech-cream px-4 py-3 text-mech-muted">
                  <MapPin size={18} />
                  <input className="w-full bg-transparent text-sm font-semibold outline-none placeholder:text-mech-muted" placeholder="Postcode" />
                </label>
                <Link href="/browse" className="inline-flex items-center justify-center gap-2 rounded-lg bg-mech-red px-6 py-3 text-sm font-black text-white hover:bg-mech-dark">
                  Browse
                  <ArrowRight size={18} />
                </Link>
              </div>
            </div>
            <div className="mt-5 flex flex-wrap gap-2">
              {cuisines.slice(1, 6).map((cuisine) => (
                <Link key={cuisine} href="/browse" className="rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-bold text-white/75 hover:bg-white hover:text-mech-dark">
                  {cuisine}
                </Link>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-white/20 bg-white/95 p-5 shadow-soft">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-widest text-mech-red">Today specials</p>
                <h2 className="font-heading text-3xl font-black">Fresh near you</h2>
              </div>
              <Clock className="text-mech-gold" size={30} />
            </div>
            <div className="grid gap-4">
              {meals.slice(0, 3).map((meal) => (
                <div key={meal.id} className="flex items-center gap-4 rounded-lg border border-mech-line bg-mech-cream p-3">
                  <div className="h-16 w-16 rounded-md bg-cover bg-center" style={{ backgroundImage: `url(${meal.imageUrl})` }} />
                  <div className="min-w-0 flex-1">
                    <h3 className="truncate font-heading text-lg font-bold">{meal.name}</h3>
                    <p className="text-sm font-semibold text-mech-muted">{meal.cook} · {meal.deliveryTime}</p>
                  </div>
                  <strong className="font-heading text-xl">£{meal.price.toFixed(2)}</strong>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white px-4 py-14 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-4 md:grid-cols-4">
          {[
            ["2 launch boroughs", "Harrow and Newham first"],
            ["30-70 min", "Flexible delivery slots"],
            ["4.8 average", "Review-led cook quality"],
            ["Fair payouts", "Commission and featured listings"]
          ].map(([value, label]) => (
            <div key={value} className="border-l-2 border-mech-gold pl-5">
              <strong className="font-heading text-3xl font-black">{value}</strong>
              <p className="mt-1 text-sm font-semibold text-mech-muted">{label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-8 flex items-end justify-between gap-4">
            <div>
              <p className="text-xs font-black uppercase tracking-widest text-mech-red">Browse</p>
              <h2 className="font-heading text-4xl font-black">Popular cuisines</h2>
            </div>
            <Link href="/browse" className="hidden items-center gap-2 text-sm font-black text-mech-red sm:flex">
              See all meals <ArrowRight size={17} />
            </Link>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {cuisines.slice(1).map((cuisine) => (
              <Link key={cuisine} href="/browse" className="rounded-lg border border-mech-line bg-white p-5 font-heading text-2xl font-bold shadow-sm hover:border-mech-red">
                {cuisine}
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-8 flex items-end justify-between gap-4">
            <div>
              <p className="text-xs font-black uppercase tracking-widest text-mech-red">Order now</p>
              <h2 className="font-heading text-4xl font-black">Today's specials</h2>
            </div>
            <Link href="/browse" className="hidden items-center gap-2 text-sm font-black text-mech-red sm:flex">
              Browse menu <ArrowRight size={17} />
            </Link>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {meals.map((meal) => (
              <MealCard key={meal.id} meal={meal} />
            ))}
          </div>
        </div>
      </section>

      <section className="fine-grid px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mb-8">
            <p className="text-xs font-black uppercase tracking-widest text-mech-red">Cook network</p>
            <h2 className="font-heading text-4xl font-black">Top rated cooks</h2>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {cooks.map((cook) => (
              <CookCard key={cook.id} cook={cook} />
            ))}
          </div>
        </div>
      </section>

      <section className="bg-mech-dark px-4 py-16 text-white sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-6 md:grid-cols-4">
            {platformFeatures.map(({ icon: Icon, title, text }) => (
              <div key={title} className="rounded-lg border border-white/10 bg-white/5 p-6">
                <Icon className="mb-5 text-mech-gold" size={28} />
                <h3 className="font-heading text-2xl font-bold">{title}</h3>
                <p className="mt-3 text-sm leading-7 text-white/60">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
