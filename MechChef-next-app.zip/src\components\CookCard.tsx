import Image from "next/image";
import { BadgeCheck, Star } from "lucide-react";
import type { CookProfile } from "@/lib/demo-data";

export function CookCard({ cook }: { cook: CookProfile }) {
  return (
    <article className="overflow-hidden rounded-lg border border-mech-line bg-white">
      <div className="relative h-44">
        <Image src={cook.imageUrl} alt={cook.name} fill className="object-cover" sizes="(min-width: 1024px) 33vw, 100vw" />
      </div>
      <div className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="font-heading text-xl font-bold">{cook.name}</h3>
            <p className="text-sm font-semibold text-mech-muted">
              {cook.cuisine} in {cook.area}
            </p>
          </div>
          {cook.verified ? <BadgeCheck className="text-mech-red" size={22} /> : null}
        </div>
        <p className="mt-3 text-sm leading-6 text-mech-muted">{cook.bio}</p>
        <div className="mt-5 grid grid-cols-3 rounded-md bg-mech-cream p-3 text-center">
          <div>
            <strong className="flex items-center justify-center gap-1 text-sm">
              <Star size={14} className="fill-mech-gold text-mech-gold" />
              {cook.rating}
            </strong>
            <span className="text-xs text-mech-muted">Rating</span>
          </div>
          <div>
            <strong className="block text-sm">{cook.orders}</strong>
            <span className="text-xs text-mech-muted">Orders</span>
          </div>
          <div>
            <strong className="block text-sm">{cook.followers}</strong>
            <span className="text-xs text-mech-muted">Followers</span>
          </div>
        </div>
      </div>
    </article>
  );
}
