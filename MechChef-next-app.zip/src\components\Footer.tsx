import Link from "next/link";
import { ChefHat } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-mech-dark text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-[1.5fr_1fr_1fr_1fr] lg:px-8">
        <div>
          <div className="mb-4 flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-lg bg-white text-mech-red">
              <ChefHat size={21} />
            </span>
            <span className="font-heading text-2xl font-black">MechChef</span>
          </div>
          <p className="max-w-sm text-sm leading-7 text-white/60">
            London first, UK next. Fresh home-cooked meals from verified local cooks, with pre-orders, tracking, and fair cook payouts.
          </p>
        </div>
        {[
          ["Customers", "Browse Meals", "Track Order", "Subscriptions", "Help"],
          ["Cooks", "Become a Cook", "Menu Management", "Earnings", "Compliance"],
          ["Company", "About", "Reviews", "Privacy", "Terms"]
        ].map((group) => (
          <div key={group[0]}>
            <h3 className="mb-4 text-xs font-bold uppercase tracking-widest text-mech-gold">
              {group[0]}
            </h3>
            <div className="grid gap-2">
              {group.slice(1).map((item) => (
                <Link key={item} href="/" className="text-sm text-white/55 hover:text-white">
                  {item}
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
    </footer>
  );
}
