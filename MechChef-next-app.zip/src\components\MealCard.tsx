import Image from "next/image";
import { Clock, Plus, Star } from "lucide-react";
import type { Meal } from "@/lib/demo-data";

export function MealCard({ meal }: { meal: Meal }) {
  return (
    <article className="overflow-hidden rounded-lg border border-mech-line bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-soft">
      <div className="relative h-48">
        <Image src={meal.imageUrl} alt={meal.name} fill className="object-cover" sizes="(min-width: 1024px) 33vw, 100vw" />
        {meal.badge ? (
          <span className="absolute left-3 top-3 rounded-full bg-mech-dark px-3 py-1 text-xs font-bold text-white">
            {meal.badge}
          </span>
        ) : null}
      </div>
      <div className="p-5">
        <div className="mb-3 flex flex-wrap gap-2">
          {meal.dietaryTags.slice(0, 2).map((tag) => (
            <span key={tag} className="rounded-full bg-mech-cream px-3 py-1 text-xs font-bold text-mech-muted">
              {tag}
            </span>
          ))}
        </div>
        <h3 className="font-heading text-xl font-bold leading-tight">{meal.name}</h3>
        <p className="mt-1 text-sm font-semibold text-mech-muted">
          {meal.cook} in {meal.area}
        </p>
        <p className="mt-3 line-clamp-2 text-sm leading-6 text-mech-muted">{meal.description}</p>
        <div className="mt-5 flex items-center justify-between">
          <div>
            <p className="font-heading text-2xl font-black">£{meal.price.toFixed(2)}</p>
            <div className="mt-1 flex items-center gap-3 text-xs font-semibold text-mech-muted">
              <span className="flex items-center gap-1">
                <Star size={14} className="fill-mech-gold text-mech-gold" />
                {meal.rating}
              </span>
              <span className="flex items-center gap-1">
                <Clock size={14} />
                {meal.deliveryTime}
              </span>
            </div>
          </div>
          <button className="grid h-11 w-11 place-items-center rounded-full bg-mech-red text-white transition hover:bg-mech-dark" aria-label={`Add ${meal.name}`}>
            <Plus size={20} />
          </button>
        </div>
      </div>
    </article>
  );
}
