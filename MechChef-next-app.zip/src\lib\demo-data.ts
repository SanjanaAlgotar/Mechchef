export type Meal = {
  id: string;
  name: string;
  cook: string;
  area: string;
  description: string;
  price: number;
  category: string;
  cuisine: string;
  dietaryTags: string[];
  rating: number;
  deliveryTime: string;
  imageUrl: string;
  badge?: string;
};

export type CookProfile = {
  id: string;
  name: string;
  area: string;
  cuisine: string;
  bio: string;
  rating: number;
  orders: number;
  followers: number;
  verified: boolean;
  imageUrl: string;
};

export const cuisines = [
  "All",
  "Indian",
  "Caribbean",
  "British",
  "Middle Eastern",
  "Italian",
  "Chinese",
  "Vegan"
];

export const meals: Meal[] = [
  {
    id: "butter-chicken",
    name: "Butter Chicken and Basmati Rice",
    cook: "Asha Patel",
    area: "Harrow",
    description:
      "Tender chicken simmered in a rich tomato-butter sauce with fragrant basmati rice.",
    price: 8.5,
    category: "Dinner",
    cuisine: "Indian",
    dietaryTags: ["Halal", "High Protein"],
    rating: 4.9,
    deliveryTime: "45-60 min",
    imageUrl: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=900&h=650&fit=crop",
    badge: "Bestseller"
  },
  {
    id: "jerk-chicken",
    name: "Jerk Chicken with Rice and Peas",
    cook: "Amara Thomas",
    area: "Newham",
    description:
      "Scotch bonnet, allspice, coconut rice, kidney beans, and crisp seasonal slaw.",
    price: 9.5,
    category: "Dinner",
    cuisine: "Caribbean",
    dietaryTags: ["Gluten Free", "Halal"],
    rating: 4.9,
    deliveryTime: "45-60 min",
    imageUrl: "https://images.unsplash.com/photo-1544025162-d76694265947?w=900&h=650&fit=crop",
    badge: "Popular"
  },
  {
    id: "sunday-roast",
    name: "Mini Sunday Roast",
    cook: "Emma Clarke",
    area: "Harrow",
    description:
      "Roast chicken, crisp potatoes, seasonal veg, Yorkshire pudding, and proper gravy.",
    price: 10.75,
    category: "Lunch",
    cuisine: "British",
    dietaryTags: ["Family Favourite"],
    rating: 4.8,
    deliveryTime: "55-70 min",
    imageUrl: "https://images.unsplash.com/photo-1544025162-d76694265947?w=900&h=650&fit=crop"
  },
  {
    id: "vegan-daal",
    name: "Black Daal with Jeera Rice",
    cook: "Nisha Rao",
    area: "Newham",
    description:
      "Slow cooked lentils, tempered spices, cumin rice, pickled onion, and coriander.",
    price: 7.25,
    category: "Lunch",
    cuisine: "Indian",
    dietaryTags: ["Vegan", "Gluten Free"],
    rating: 4.7,
    deliveryTime: "35-50 min",
    imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=900&h=650&fit=crop",
    badge: "Fresh today"
  },
  {
    id: "mezze-box",
    name: "Mezze Lunch Box",
    cook: "Layla Haddad",
    area: "Harrow",
    description:
      "Hummus, tabbouleh, roasted vegetables, flatbread, pickles, and tahini dressing.",
    price: 8.25,
    category: "Lunch",
    cuisine: "Middle Eastern",
    dietaryTags: ["Vegetarian"],
    rating: 4.8,
    deliveryTime: "30-45 min",
    imageUrl: "https://images.unsplash.com/photo-1544510808-91bcbee1df55?w=900&h=650&fit=crop"
  },
  {
    id: "lasagne",
    name: "Home Baked Beef Lasagne",
    cook: "Marco Bellini",
    area: "Newham",
    description:
      "Layers of slow beef ragu, pasta, bechamel, parmesan, and a simple dressed salad.",
    price: 9.75,
    category: "Dinner",
    cuisine: "Italian",
    dietaryTags: ["High Protein"],
    rating: 4.6,
    deliveryTime: "50-65 min",
    imageUrl: "https://images.unsplash.com/photo-1574894709920-11b28e7367e3?w=900&h=650&fit=crop"
  }
];

export const cooks: CookProfile[] = [
  {
    id: "asha",
    name: "Asha Patel",
    area: "Harrow",
    cuisine: "Gujarati and Punjabi",
    bio: "A verified home cook specialising in balanced tiffins, family curries, and comfort food.",
    rating: 4.9,
    orders: 228,
    followers: 1180,
    verified: true,
    imageUrl: "https://images.unsplash.com/photo-1556911220-bff31c812dba?w=700&h=700&fit=crop"
  },
  {
    id: "amara",
    name: "Amara Thomas",
    area: "Newham",
    cuisine: "Caribbean",
    bio: "Weekend specials, jerk marinades, and generous plates inspired by family recipes.",
    rating: 4.9,
    orders: 184,
    followers: 840,
    verified: true,
    imageUrl: "https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=700&h=700&fit=crop"
  },
  {
    id: "layla",
    name: "Layla Haddad",
    area: "Harrow",
    cuisine: "Middle Eastern",
    bio: "Fresh mezze, warm breads, and lunch boxes made for office teams and families.",
    rating: 4.8,
    orders: 132,
    followers: 610,
    verified: true,
    imageUrl: "https://images.unsplash.com/photo-1577219491135-ce391730fb2c?w=700&h=700&fit=crop"
  }
];
